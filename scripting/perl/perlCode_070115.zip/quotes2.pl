#!/bin/perl -w
# bp 17

print "\n";
print 'print "C:\\\\WINNT\\\\Profiles\\\\\\n";', "\n";
print "C:\\WINNT\\Profiles\\\n";
print "\n";
print 'print \'C:\WINNT\Profiles\ \'', "\n";
print 'C:\WINNT\Profiles\ ', "\n";
print "\n";
print qq/"'single quotes inside double qoutes (unlike bash)'"/."\n";
print "'single quotes inside double qoutes (unlike bash)'"."\n";
print "\n";
print qq/'"double quotes inside single qoutes"'/."\n";
print '"double quotes inside single qoutes"'."\n";
print "\n";
