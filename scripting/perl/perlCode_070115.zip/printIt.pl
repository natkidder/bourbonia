#!/bin/perl -w
# bp 261 
# called by doThis.pl

print "\n";
###my @fullpath = split($0, '/'); 
###my $lastpath = pop(@fullpath);  print $0 . " " . $lastpath . "\n";
###print "$fullpath[$#fullpath-1]\n";
print $0 . ":\n";  ###
print 'print $a;' . "\n";
print 'print "This should go to standard output...\n";' . "\n";
print "\n";

print $a;
print "This should go to standard output...\n";
