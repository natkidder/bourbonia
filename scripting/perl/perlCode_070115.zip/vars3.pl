#!/bin/perl -w

# bp 38

print "\nYou can also perl -w <file>\n\n";

print "\n";
$a = 6 * 9;
print "six nines are ", $a, "\n";
$b = $a + 3;
print "Plus three is ", $b, "\n";
$c = $b / 3;
print "All over three is ", $c, "\n";
$d = $c + 1;
print "Add one is ", $d, "\n";
print "Those stages again: ", $a, " ", $b, " ", $c, " ", $d, "\n";
print "\n";
