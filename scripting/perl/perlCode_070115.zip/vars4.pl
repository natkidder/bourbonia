#!/bin/perl -w

# bp 38

print "\nYou can also perl -w <file>\n\n";

print "\n";
$a = 6 * 9;
print "six nines are ", $a, "\n";
$a = $a + 3;
print "Plus three is ", $a, "\n";
$a = $a / 3;
print "All over three is ", $a, "\n";
$a = $a + 1;
print "Add one is ", $a, "\n";
print "Those stages again: ", $a, " ", $a, " ", $a, " ", $a, "\n";
print "\n";
