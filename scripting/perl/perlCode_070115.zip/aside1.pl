#!/bin/perl -w
# bp 18

print 'print \'ex\\\\ er\\\\\', \' ci\\\' se\\\'', "\n";
print 'ex\\ er\\', ' ci\' se\'', "\n";
