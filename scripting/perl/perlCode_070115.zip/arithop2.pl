#!/bin/perl
# bp 22

print "\n";
print 'print "21 from 25 is: ", 25 - 21' . "\n";
print "21 from 25 is: ", 25 - 21, "\n";
print "\n";
print 'print "4 + 13 - 7 is: ", 4 + 13 - 7' . "\n";
print "4 + 13 - 7 is: ", 4 + 13 - 7, "\n";
print "\n";
