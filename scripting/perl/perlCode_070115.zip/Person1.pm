# bp 264 -- opening #!/bin/perl unneccesary as it's a package

# class for storing data about a person

use strict;

1;  ## ALWAYS end a package with a 1
