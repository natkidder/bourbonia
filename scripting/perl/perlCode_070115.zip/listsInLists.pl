#!/bin/perl - w

# bp 80

use strict;

print "\n";
print 'my @ary = ((1,2),(3,4));' . "\n";
print 'my $elem = $ary[0];' . "\n";
print "\n";

my @ary = ((1,2),(3,4));
my $elem = $ary[0];
print "\@ary first element (\@ary[0]) is $elem\n";

print "\n";
