#!/bin/perl
# bp 20

print "\nyou can also do: $ /bin/perl autoconvert.pl\n\n";

print 'print "0.25" * 4'."\n\n";
print "0.25" * 4, "\n";
print "\n";
