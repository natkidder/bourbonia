#!/bin/perl -w
# bp 33

print "\n'\$ perl -w <filename>.pl' will run the program complete with warnings\n";

print "\n";
print 'print "12 monkeys"    + 0' . "\n";
print "12 monkeys"    + 0, "\n";
print "\n";
print 'print "Eleven to fly" + 0' . "\n";
print "Eleven to fly" + 0, "\n";
print "\n";
print 'print "UB40"          + 0' . "\n";
print "UB40"          + 0, "\n";
print "\n";
print 'print "-20 10"        + 0' . "\n";
print "-20 10"        + 0, "\n";
print "\n";
print 'print "0x30"          + 0' . "\n";
print "0x30"          + 0, "\n";
print "\n";
