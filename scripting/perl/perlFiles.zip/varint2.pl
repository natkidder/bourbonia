#!/bin/perl -w

# bp 44

use strict;

print "\n";

print 'my $name = "fred"' . "\n";
my $name = "fred";

print "print 'My name is \\$name, $name\\n'" . "\n";
print 'My name is \$name, $name\n';

print "\n\n";
