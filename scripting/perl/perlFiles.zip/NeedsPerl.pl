print "hello, world\n";
