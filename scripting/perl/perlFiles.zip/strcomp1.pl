#!/bin/perl -w
# bp 34

print "\n";
print "Which came first, the chicken or the egg (\"chicken\" cmp \"egg\") ? ";
print "chicken" cmp "egg", "\n";
print "\n";
print "Are dogs greater than cats ('dog' gt 'cat') ? ";
print 'dog' gt 'cat', "\n";
print "\n";
print "Is ^ less than + ('^' lt '+') ? ";
print '^' lt '+', "\n";
print "\n";
