#!/bin/perl -w
# bp 28

print "\n";
print "So, two is not equal to four (2 != 4) ? ", 2 != 4, "\n";
print "\n";
