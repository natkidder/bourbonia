#!/bin/perl -w

print "\n'\$ perl -w <filename>.pl' will run the program complete with warnings\n";
print "\n";
print "A # has ASCII value ord('#') or ", ord('#'), "\n";
print "\n";
print "A * has ASCII value ord(\"*\") or ", ord("*"), "\n";
print "\n";
