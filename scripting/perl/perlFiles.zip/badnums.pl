#!/bin/perl -w
# bp 14

print ' 255, 0378,	 0b11111112, 0xFG', "\n";	
print 255,		"\n";
print 0378,		"\n";
print 0b11111112,	"\n";
print 0xFG,		"\n";
