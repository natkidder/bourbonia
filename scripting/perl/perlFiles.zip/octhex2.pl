#!/bin/perl
# bp 21

print "\n".'print hex("0x30")' . "\n";
print hex("0x30"), "\n";
print "\n".'print oct("030")' . "\n";
print oct("030"), "\n";
print "\n".'print oct("0b11010")' . "\n";
print oct("0b11010"), "\n";
print "\n";
