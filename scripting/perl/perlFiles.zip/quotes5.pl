#!/bin/perl
# bp 19

print "\n";
print qq#print qq/'"Hi, " said Jack, "Have you read Slashdot today?"'/#;
print "\n";
print qq/'"Hi, " said Jack, "Have you read Slashdot today?"'\n/;
print "\n";
print 'NOTE: qq//I am in a dbl-quote// doesn\'t seem to work'."\n";
print "\n";
