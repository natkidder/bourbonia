#!/bin/perl
# bp 19

print "'\"Hi,\" said Jack, \"Have you read Slashdot today?\"'\n";

print '\'"Hi," said Jack, "Have you read Slashdot today?"\'' . "\n";
