#!/bin/perl
# bp 31

print "\n";
print 'print "Ba" . "na" x 4' . "\n";
print "Ba" . "na" x 4, "\n";
print "\n";
