#!/bin/perl
# bp 29

print "\n";
print "Seven is less than or equal to sixteen (7 <= 16) ? '", 7 <= 16, "'\n";
print "\n";
print "Two is more than or equal to two (2 >= 2) ? '", 2 >= 2, "'\n";
print "\n";
