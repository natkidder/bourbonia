#!/bin/perl
# bp 22

print "\n";
print 'print "7 times 15 is: ", 7 * 15' . "\n";
print "7 times 15 is: ", 7 * 15, "\n";
print "\n";
print 'print "249 divided by 3 is: ", 249 /3' . "\n";
print "249 divided by 3 is: ", 249 /3, "\n";
print "\n";
