#!/bin/perl -w

# bp 68

use strict;

my $number;

print "\n" . 'foreach $number (1..10) {' . "\n\n";

foreach $number (1..10) {
  print "the number is: $number\n";
}
print "\n";
