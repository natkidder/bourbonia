#!/bin/perl -w

# bp 78

use strict;

print "\n";
print 'print(123, 456, 789);' . "\n";
print "\n";

print(123, 456, 789);
print "\n\n";

