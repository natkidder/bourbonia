#!/bin/perl -w

use strict;

open(F1,">golf2.unx");
print F1 "rm perlFileContents.txt";
close F1;
system("ls *.pl >> golf1.txt");

open(F1, <, "golf1.txt");
open(F2, ">> golf2.unx");
while (<F1>) {
  print F2 "cat " . $_ . " >> perlFileContents.txt"
}
close F2;
close F1;
