#!/bin/perl -w
# bp 31

print "\n";
print 'print "Ba" . "na" x 4*3' . "\n";
print "Ba" . "na" x 4*3, "\n";
print "\n";
print 'print "Ba" . "na" x (4*3)' . "\n";
print "Ba" . "na" x (4*3), "\n";
print "\n";
