#!/bin/perl
# bp 26

print "\n";
print "We are using 64-bit\n";
print "\n";
print "NOT 85 (~85) is ", ~85, "\n";
print "\n";
print "2**30 in decimal                     ", 2**30, "\n";
print "2**30 in octal, oct(2**30) is        ", oct(2**30), "\n";
print "NOT 2**30 in octal, oct(~(2**30)) is ", oct(~(2**30)), "\n";
print "\n";
