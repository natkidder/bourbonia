#!/bin/perl -w

# bp 70

use strict;

my $i = 1;

print "\nThe difference with do..while and do..until is the action is performed at least once\n\n";
print "do {..} while ($i < 6) -and- do {...} until ($i >= 6);\n\n";

print "starting do..while:\n";
do {
  print "   the value of \$i: $i\n";
  $i++;
} while ($i < 6);

print "\n";
$i = 1;

print "starting do..until:\n";
do {
  print "   the value of \$i: $i\n";
  $i++;
} until ($i >= 6);
print "\n";
