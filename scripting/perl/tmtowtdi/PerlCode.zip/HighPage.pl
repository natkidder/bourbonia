#!/bin/perl

use strict;

my $line = "";
my $MaxLine = "";
my $PageNbr = 0;
my $MaxPage = 0;

system("grep 'bp ' *.pl > golf.txt");
#open (F1, system("grep 'bp ' *.pl|");
open (F1, "< golf.txt") ;
while (<F1>) {
  $line = $_;
  $PageNbr = substr($line,length($line)-4,4);
  $PageNbr += 0;
#  print $line . "\t" . $PageNbr. "\n"; ####
  if ($PageNbr > $MaxPage) {
    $MaxPage = $PageNbr; 
    $MaxLine = $line;
  }
}
print "Highest Page = ", $MaxPage, "\n";
print "Line is: ", $MaxLine, "\n";
