#!/bin/perl -w
# bp 17

print '\tThis is a single quoted string.\n';
print "\tThis is a double quoted string.\n";
