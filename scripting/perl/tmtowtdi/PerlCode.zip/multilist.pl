#!/bin/perl -w

# bp 86

use strict;

my $mOne;
my $mTwo;

print "\n\n";
print '($mOne,$mTwo) = (1,3);' . "\n";
print 'print(("heads","shoulders","knees","toes")[$mOne, $mTwo]);' . "\n";
print "\n";

($mOne,$mTwo) = (1,3);
print(("heads","shoulders","knees","toes")[$mOne, $mTwo]);

print "\n";
print "\n";
