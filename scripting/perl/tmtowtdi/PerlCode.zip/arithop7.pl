#!/bin/perl
# bp 23

print "\n";
print '2**4, " ", 3**5, " ", -2**4' . "\n";
print 2**4, " ", 3**5, " ", -2**4, "\n\n";
print '(-2)**4' . "\n";
print (-2)**4;
print "\n\n";
