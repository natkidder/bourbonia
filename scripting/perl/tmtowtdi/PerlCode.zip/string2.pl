#!/bin/perl
# bp 31

print "\n";
print 'print "GO! " x 3', "\n";
print "\n";
print "GO! " x 3, "\n";
print "\n";
