#!/bin/perl

# bp 37

$name = "fred";
print "\n";
print "My name ($name) is ", $name, "\n";
print "\n";
