#!/bin/perl -w
# bp 15

use strict;

print 'print "pi is about ", 3.14159, "\n";',"\n";
print "pi is about ", 3.14159, "\n";
