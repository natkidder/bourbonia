#!/bin/perl
# bp 31

print "\n";
print "Four sevens are (4*7) ", 4*7 , "\n";
print "\n";
