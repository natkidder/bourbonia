#!/bin/perl
# bp 25

print "\n";
print "51 ANDed with 85 (51 & 85, or 85 & 51) gives us: ", 51 & 85, "\n";
print "\n";
print "51 ORed with 85 (51 | 85, or 85 | 51) gives us: ", 51 | 85, "\n";
print "\n";
print "51 XORed with 85 (51 ^ 85, or 85 ^ 51) gives us: ", 51 ^ 85, "\n";
print "\n";
