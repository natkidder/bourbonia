#!/bin/perl
# bp 18

system("tput clear");

print 'you may do without #!/bin/perl by typing: $ perl quotes3.pl', "\n";

print 'print "It\'s as easy as that.\n"'. "\n";
print "It's as easy as that.\n";
print 'print \'"Stop," he cried.\', "\n";' . "\n";
print '"Stop," he cried.', "\n";
print "\n";
