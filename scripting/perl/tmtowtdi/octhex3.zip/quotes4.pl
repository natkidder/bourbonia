#!/bin/perl
# bp19

print "'\"Hi,\" said Jack, \"Have you read Slashdot today?\"'\n";

print '\'"Hi," said Jack, "Have you read Slashdot today?"\'' . "\n";
