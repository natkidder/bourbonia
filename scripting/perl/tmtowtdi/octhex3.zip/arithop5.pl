#!/bin/perl -w
# bp 23

print "\n";
print 'print "(3 plus 7) times 15 is: ", (3 + 7) * 15' . "\n";
print "(3 plus 7) times 15 is: ", (3 + 7) * 15, "\n";
print "\n";
print 'print (3 + 7) * 15' . "\n";
print (3 + 7) * 15, "\n";
print "\n\n";
