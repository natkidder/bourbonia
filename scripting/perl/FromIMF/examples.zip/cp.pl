#! /bin/perl

#use File::Copy;
#copy("file1","file2");
#copy("Copy.pm",\*STDOUT);'
#move("/dev1/fileA","/dev2/fileB");
#use POSIX;
#use File::Copy cp;
#$n = FileHandle->new("/a/file","r");
#cp($n,"x");'
