#!/bin/perl

my $i = 1;

#{print "first stmt\n"; print "second stmt";} if $i > 0;
print "first stmt\n" if $i > 0;
