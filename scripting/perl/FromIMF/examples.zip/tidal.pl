#! /bin/perl
use DBI;
$dbh = DBI->connect("dbi:Oracle:host=ADMIRAL;sid=tidalprd",nkidder,wlypb);

