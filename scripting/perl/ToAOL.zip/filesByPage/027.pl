#!/bin/perl -w
# bp 27 

print "\nCan run this with the /bin/perl prefix, sans the shebang line\n";
print "\n";
print 'print "Is two equal to four ?    \'", 2 == 4, '. "\'\n";
print 'print "OK, is six equal to six ? \'", 6 == 6, '. "\'\n";
print "Is two equal to four ?    '", 2 == 4, "'\n";
print "OK, is six equal to six ? '", 6 == 6, "'\n";
print "\n";
