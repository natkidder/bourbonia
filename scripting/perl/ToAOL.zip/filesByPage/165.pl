#!/bin/perl -w

print "to exit, press '^z'\n";
while (1==1) {
  system("./165A.pl");
} 
##  last if $_ = exit;
##  print "You ran it\n";
