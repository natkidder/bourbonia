#!/bin/perl -w
# bp 15

use strict;

print "\n";
print 'print "pi is about ", 3.14159, "\n";',"\n";


print "pi is about ", 3.14159, "\n";
print "\n";
