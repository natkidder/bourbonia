#!/bin/perl -w




print "\n";

