#!/bin/perl -w

# bp 45

use strict;

print "\n";
print 'my $times = 8' . "\n";
print 'print "This is the ${times}th time"' . "\n";
print "\n";
my $times = 8;
print "This is the ${times}th time\n\n";
print "\n";
