#!/bin/perl
# bp 24

print "\n";
print "15 divided by 6 (15 / 6) is exactly ", 15 / 6, "\n";
print "That's a remainder of 15 % 6 or ", 15 % 6, "\n";
print "\n";
