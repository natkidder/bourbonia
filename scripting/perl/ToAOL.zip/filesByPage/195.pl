#!/bin/perl -w
# bp 195
# NOTE: called sort2.pl there, there was already on on p. 109

use strict;

print "\n";
print 'sortFile2.pl: my @text = <>;' . "\n";
print 'sortFile2.pl: print sort @text;' . "\n";
print "\n";


my @text = <>;

print sort @text;

print "\n";
