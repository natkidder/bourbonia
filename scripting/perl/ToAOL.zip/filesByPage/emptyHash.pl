#!/bin/perl 

use warnings;

my %a = qw//;
print "'", scalar %a , "'";
