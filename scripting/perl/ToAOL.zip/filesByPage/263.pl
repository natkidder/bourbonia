#!/bin/perl -w
# bp 263

use strict;

print "\n";
print 'use lib "/cygdrive/c/mydocs/career/training";' . "\n";
print "\n";

use lib "/cygdrive/c/mydocs/career/training";

require "is_there.pl";
