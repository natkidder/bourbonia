#!/bin/perl -w


showNbr();

sub showNbr {
  $arg = shift || 7;
  print $arg, "\n";
}
