#!/bin/perl -w

warn "Warning! said the robot to Dr. Smith";
print "\n";
print "print";
print "\n";
die "die";
print "\n";
