#!/bin/perl -w

# bp 92

use strict;

print "\n";
print 'my @array = (1, 3, 5, 7, 9);' . "\n";
print 'print @array[1];' . "\n";
print "\n";


my @array = (1, 3, 5, 7, 9);
print @array[1];

print "\n\n";
