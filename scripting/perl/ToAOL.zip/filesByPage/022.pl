#!/bin/perl
# bp 22

print "\n";
print 'print 69 + 118' . "\n\n";
print 69 + 118, "\n\n";
