#!/bin/perl -w

foreach $arg (@ARGV) {
  print "$arg\n";
}
