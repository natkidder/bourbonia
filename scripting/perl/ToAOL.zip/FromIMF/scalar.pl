#!/bin/perl

my @test = qw/a b c d e/;
print scalar(@test) . "\n";
