die "Unable to create directory:\n  $target\nbecause:\n  $!\n"
    unless -d $target
        || mkdir $target;
