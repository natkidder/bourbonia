#!/bin/perl -w
# bp 15

print 'print 255, 0377, 0b11111111, 0xFF respectively'."\n";
print 255,		"\n";
print 0377,		"\n";
print 0b11111111,	"\n";
print 0xFF,		"\n";
