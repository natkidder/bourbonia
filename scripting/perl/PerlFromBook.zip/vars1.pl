#!/bin/perl

# bp 37

print $0 . "\n";

$name = "fred";
print "\n";
print "My name ($name) is ", $name, "\n";
print "\n";
