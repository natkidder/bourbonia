#!/bin/perl
# bp 21

print "\n" . 'print hex("FFG")' . "\n";
print hex("FFG"), "\n";
print "\n" . 'print oct("178")' . "\n";
print oct("178"), "\n";
print "\n";
