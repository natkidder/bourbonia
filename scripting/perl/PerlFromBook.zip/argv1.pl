#!/bin/perl -w

use strict;

print "\n";
print 'print "[$_]\n" foreach @ARGV;' . "\n";
print "\n";


print "[$_]\n" foreach @ARGV;

print "\n";
