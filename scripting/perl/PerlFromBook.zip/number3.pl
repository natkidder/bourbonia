#!/bin/perl
# bp 14

print 'print 25_000_000, " ", -4, "\n"',"\n";
print 25_000_000, " ", -4, "\n";
