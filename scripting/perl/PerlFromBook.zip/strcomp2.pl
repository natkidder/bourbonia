#!/bin/perl -w
# bp 35

print "\n";
print 'print "Test one: ", "four" eq "six"' . "\n";
print "Test one: ", "four" eq "six", "\n";
print "\n";
print 'print "Test two: ", "four" == "six"' . "\n";
print "Test two: ", "four" == "six", "\n";
print "\n";
