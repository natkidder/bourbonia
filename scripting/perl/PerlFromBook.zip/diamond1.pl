#!/bin/perl -w

# bp 184

use strict;

print "\n";
print 'print "text read: $_"; while (<>) ' . "\n";
print "\n";


while (<>) {
  print "text read: $_";
}
