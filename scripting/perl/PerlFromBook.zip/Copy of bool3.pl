#!/bin/perl
# bp 28

print "\n";
print "Fix is more than six (5 > 6) ? '", 5 > 6, "'\n";
print "\n";
print "Seven is less than sixteen (7 < 16) ? '", 7 < 16, "'\n";
print "\n";
print "Two is equal to two (2 == 2) ? '", 2 == 2, "'\n";
print "\n";
print "One is more than one (1 > 1) ? '", 1 > 1, "'\n";
print "\n";
print "Six is not equal to seven (6 != 7) ? '", 6 != 7, "'\n";
print "\n";
