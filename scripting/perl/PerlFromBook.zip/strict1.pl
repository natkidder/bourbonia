#!/bin/perl -w

# bp 140

use strict;

$x = 10;
print $x;
