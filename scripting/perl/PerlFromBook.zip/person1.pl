#!/bin/perl -w
# bp 265

print "\n";
print 'use strict;' . "\n";
print 'use Person1; ## from Person1.pm' . "\n";
print "\n";

use strict;
use Person1;
