#!/bin/perl
# bp 21

print "\n".'print "0x30"'."\n";
print "0x30\n";
print "\n";
print 'print "030"'."\n";
print "030\n";
print "\n";
