#!/bin/perl
# bp 29

print "\n";
print "Compare six and nine (6 <=> 9) ? '", 6 <=> 9, "'\n";
print "\n";
print "Compare seven and seven (7 <=> 7) ? '", 7 <=> 7, "'\n";
print "\n";
print "Compare eight and four (8 <=> 4) ? '", 8 <=> 4, "'\n";
print "\n";
