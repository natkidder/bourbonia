-- generic anonymous block of code

declare
-- nothing
begin
  null;
exception
  when others then null;
end;
/
