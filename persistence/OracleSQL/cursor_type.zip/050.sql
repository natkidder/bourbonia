/* example of trim */

select trim(both '-' from '---slob--') from dual
/
