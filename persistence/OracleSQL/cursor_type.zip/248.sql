insert into prod_types2 (prod_type, prod_desc) values ('electrical', 'lighting, outlets, wiring, breakers');
insert into prod_types2 (prod_type, prod_desc) values ('garden', 'plants, shrubs, mulch, seed, fertilizer');
insert into prod_types2 (prod_type, prod_desc) values ('paint', 'paint, varnish, brushes, rollers');
insert into prod_types2 (prod_type, prod_desc) values ('toys', 'games, kits, dolls, tricycles');
