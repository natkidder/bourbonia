-- small program giving an untrapped error

declare
  e_sample exception;
begin
  raise e_sample;
end;
