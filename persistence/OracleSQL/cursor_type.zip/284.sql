-- sample grant statements

grant create session to turner;
grant create table to turner;
grant create sequence to turner;
grant create procedure to turner;
