-- you can mix datatypes in list functions

select greatest('fred',314.15,'22-jan-04') from dual
/
