declare
  myvar2 number default 0;
begin
  no_op(5,myvar2);
end;
/
