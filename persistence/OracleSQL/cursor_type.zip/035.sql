select * from emp
/
