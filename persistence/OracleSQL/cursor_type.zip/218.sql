-- updating multiple columns on a single row

update employee set
lastname = 'ATHENA', firstname = 'BAMBINA'
where empid = '49392'
/
