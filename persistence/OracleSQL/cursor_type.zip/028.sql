/* distinct example */
select distinct deptno from emp;
