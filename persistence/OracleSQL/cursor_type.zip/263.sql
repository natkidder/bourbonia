create sequence countdown_20
start with 20
increment by -1
maxvalue 20
minvalue 0
cycle
order
cache 2
/
