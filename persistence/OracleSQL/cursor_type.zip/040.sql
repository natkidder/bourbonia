select ename, sal from emp
where sal > 2000
order by sal desc
/
