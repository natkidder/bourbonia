declare
begin
  insert into companies (COMPANY_NAME) values ('Gannett');
declare
begin
  insert into companies (COMPANY_NAME) values ('IKON');
declare
begin
  insert into companies (COMPANY_NAME) values ('Keane');
declare
begin
  insert into companies (COMPANY_NAME) values ('Musicmaker.com');
declare
begin
  insert into companies (COMPANY_NAME) values ('Cysive');
declare
begin
  insert into companies (COMPANY_NAME) values ('RedSiren');
declare
begin
  insert into companies (COMPANY_NAME) values ('American Soc of Civil Eng');
declare
begin
  insert into companies (COMPANY_NAME) values ('Digital Harbor');
declare
begin
  insert into companies (COMPANY_NAME) values ('Software AG');
declare
begin
  insert into companies (COMPANY_NAME) values ('Titan');
declare
begin
  insert into companies (COMPANY_NAME) values ('Siemens');
declare
begin
  insert into companies (COMPANY_NAME) values ('Intelligence Data Systems');
declare
begin
  insert into companies (COMPANY_NAME) values ('BT');
declare
begin
  insert into companies (COMPANY_NAME) values ('iMC');
declare
begin
  insert into companies (COMPANY_NAME) values ('TNS');
declare
begin
  insert into companies (COMPANY_NAME) values ('Nextel');
declare
begin
  insert into companies (COMPANY_NAME) values ('ComSearch');
declare
begin
  insert into companies (COMPANY_NAME) values ('Raytheon Technical Services');
declare
begin
  insert into companies (COMPANY_NAME) values ('Lockheed Martin');
declare
begin
  insert into companies (COMPANY_NAME) values ('Lafarge');
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
end;
