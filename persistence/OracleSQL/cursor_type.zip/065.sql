select to_char(new_time(to_date('15-mar-03 14:35:00',
'dd-mon-yyyy hh24:mi:ss'), 'AST','GMT'))
FROM DUAL
/
