-- simple cursor declaration example

declare
  cursor c_emp is select * from emp;
begin
  null;
end;
/
