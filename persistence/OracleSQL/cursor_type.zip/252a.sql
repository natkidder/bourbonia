update prod_types2 set depot_loc = 'dayton' where prod_type = 'electrical';
update prod_types2 set depot_loc = 'san antonio' where prod_type = 'garden';
update prod_types2 set depot_loc = 'macon' where prod_type = 'paint';
update prod_types2 set depot_loc = 'sacramento' where prod_type = 'toys';
/
