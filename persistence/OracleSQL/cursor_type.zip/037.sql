select empno, ename, sal, mgr
from emp
order by mgr, empno
/
