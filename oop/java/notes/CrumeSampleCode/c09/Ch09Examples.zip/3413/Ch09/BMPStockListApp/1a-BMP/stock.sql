drop table stock;

create table stock  
(tickerSymbol varchar(10) constraint pk_stock primary key,  
name varchar(50));
