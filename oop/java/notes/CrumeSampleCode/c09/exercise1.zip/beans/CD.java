package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface CD extends EJBObject  {
  // get the name
  public String getName() throws RemoteException;
  
  // get and set the price
  public double getPrice() throws RemoteException;
  public void setPrice(double price) throws RemoteException;
}