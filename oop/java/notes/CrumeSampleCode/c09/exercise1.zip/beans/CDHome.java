package beans;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

public interface CDHome extends EJBHome {
  public CD create(String name, double price)
    throws CreateException, RemoteException;
  
  public CD findByPrimaryKey(String name)
    throws FinderException, RemoteException;
}