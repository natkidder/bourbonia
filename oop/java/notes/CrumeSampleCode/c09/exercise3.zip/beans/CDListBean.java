package beans;

import java.util.Collection;
import java.util.Iterator;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class CDListBean implements SessionBean {
  
  // the public business methods. these must be coded in the 
  // remote interface also. 
  
  public Object[][] getAllCDs() throws FinderException {
    try {
      LocalCDHome cdHome = getCDHome();
      Collection cdColl = cdHome.findAllCDs();
      Object[][] cds = new Object[cdColl.size()][2];
      int j = 0;
      Iterator i = cdColl.iterator();
      while (i.hasNext()) {
        LocalCD cd = (LocalCD) i.next();
        cds[j][0] = cd.getName();
        cds[j++][1] = new Double(cd.getPrice());
      }
      
      return cds;
    }
    catch (FinderException fe) {
      throw fe;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  public Object[][] getAllCDsInRange(double lower, double upper)
    throws FinderException {
    try {
      LocalCDHome cdHome = getCDHome();
      Collection cdColl = cdHome.findAllCDsInRange(lower, upper);
      Object[][] cds = new Object[cdColl.size()][2];
      int j = 0;
      Iterator i = cdColl.iterator();
      while (i.hasNext()) {
        LocalCD cd = (LocalCD) i.next();
        cds[j][0] = cd.getName();
        cds[j++][1] = new Double(cd.getPrice());
      }
      
      return cds;
    }
    catch (FinderException fe) {
      throw fe;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  private LocalCDHome getCDHome() throws NamingException {
    // get the initial context
    InitialContext initial = new InitialContext();
    
    // get the object reference
    Object objref = initial.lookup("java:comp/env/ejb/beans.CD");
    LocalCDHome home = (LocalCDHome) objref;
    return home;
  }
  

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}