package beans;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface CDListHome extends EJBHome {
  public CDList create()
    throws CreateException, RemoteException;
}