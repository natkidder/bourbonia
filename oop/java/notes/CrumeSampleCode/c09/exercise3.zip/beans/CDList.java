package beans;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

public interface CDList extends EJBObject {
  public Object[][] getAllCDs()
    throws FinderException, RemoteException;
  public Object[][] getAllCDsInRange(double lower, double upper)
    throws FinderException, RemoteException;
}