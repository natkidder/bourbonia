package client;

import beans.CDList;
import beans.CDListHome;

import java.text.NumberFormat;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class CDClient { 
  
  public static void main(String[] args) {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the CDList JNDI entry
      Object ref = jndiContext.lookup("ejb/beans.CDList");

      // Get a reference from this to the Bean's Home interface
      CDListHome home = (CDListHome)
        PortableRemoteObject.narrow(ref, CDListHome.class);

      // Create a CDList object from the Home interface
      CDList cdList = home.create();
      
      NumberFormat nf = NumberFormat.getCurrencyInstance();
      
      System.out.println("\nAll CDs Ascending by Name:"); 
      Object[][] allCds = cdList.getAllCDs();
      for (int i = 0; i < allCds.length; i++) {
        String name = (String) allCds[i][0];
        Double price = (Double) allCds[i][1];
        System.out.println("Title: " + name + "Price: " + 
          nf.format(price.doubleValue()));
      }
      
      System.out.println("\nAll CDs in Price Range: $15.00 to " +
        "$20.00 - Ascending by Name"); 
      Object[][] allCdsInRange = cdList.getAllCDsInRange(15.00, 20.00);
      for (int i = 0; i < allCdsInRange.length; i++) {
        String name = (String) allCdsInRange[i][0];
        Double price = (Double) allCdsInRange[i][1];
        System.out.println("Title: " + name + "Price: " + 
          nf.format(price.doubleValue()));
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}