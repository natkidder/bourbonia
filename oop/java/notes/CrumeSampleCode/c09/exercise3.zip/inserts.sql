insert into CDEJB values (16.95, 'Aerosmith: Toys in the Attic');
insert into CDEJB values (18.95, 'Queen: Night at the Opera');
insert into CDEJB values (17.50, 'The Beatles: A Hard Days Night');
insert into CDEJB values (10.95, 'The Chipmonks: Chipmonk Christmas');
insert into CDEJB values (21.95, 'The Beach Boys: Endless Summer');