package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface Mirror extends EJBObject {
  // the public business method on the Mirror bean
  public String reverseIt(String clientString)
    throws RemoteException;
}