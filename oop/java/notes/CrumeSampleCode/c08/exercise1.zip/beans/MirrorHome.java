package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.CreateException;

public interface MirrorHome extends EJBHome {
  // the create method for the Mirror bean.
  public Mirror create()
    throws CreateException, RemoteException;
}