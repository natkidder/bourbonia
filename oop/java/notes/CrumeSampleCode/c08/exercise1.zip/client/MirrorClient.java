package client;

import beans.Mirror;
import beans.MirrorHome;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class MirrorClient { 
  public static void main(String[] args) {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the Mirror JNDI entry
      Object ref  = jndiContext.lookup("ejb/beans.Mirror");

      // Get a reference from this to the bean's Home interface
      MirrorHome home = (MirrorHome)
       PortableRemoteObject.narrow(ref, MirrorHome.class);

      // Create a Mirror object from the Home interface
      Mirror mirror = home.create();
      
      // loop through the words
      for (int i = 0; i < args.length; i++) {
        String returnedString =
          mirror.reverseIt(args[i]);
        System.out.println("sent string: " + args[i]
          + ", received string: " + returnedString);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}