package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.CreateException;

public interface BuilderHome extends EJBHome {
  // the create method for the Builder bean.
  public Builder create()
    throws CreateException, RemoteException;
}