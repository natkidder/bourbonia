package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface Builder extends EJBObject {
  // the public business method on the Builder bean
  public String addWord(String word)
    throws RemoteException;
}