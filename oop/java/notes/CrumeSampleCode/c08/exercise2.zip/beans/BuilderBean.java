package beans;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class BuilderBean implements SessionBean {
  // save the sentence
  private StringBuffer _sentence = new StringBuffer();
  
  // the public business method.
  public String addWord(String word) {
    _sentence.append(_sentence.length() == 0 ? "" : " ");
    _sentence.append(word);
    return _sentence.toString();
  }

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}