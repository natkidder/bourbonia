package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.CreateException;

public interface CounterHome extends EJBHome {
  // the create method for the Counter bean.
  public Counter create()
    throws CreateException, RemoteException;
}