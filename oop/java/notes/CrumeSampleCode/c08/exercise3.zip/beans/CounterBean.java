package beans;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class CounterBean implements SessionBean {
  
  // the public business method.
  public int countLetters(String word) {
    return word.trim().length();
  }

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}