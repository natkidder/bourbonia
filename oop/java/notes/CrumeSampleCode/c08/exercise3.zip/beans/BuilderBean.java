package beans;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class BuilderBean implements SessionBean {
  // save the sentence
  private StringBuffer _sentence = new StringBuffer();
  private int _letters = 0;
  
  // the public business method.
  public String addWord(String word) {
    if (_sentence.length() > 0) {
      _sentence.append(" ");
      _letters++;
    }
    _sentence.append(word);
    _letters += getCount(word);
    return _sentence.toString() + _letters;
  }
  
  private int getCount(String word) {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the Counter JNDI entry
      Object ref  = jndiContext.lookup("ejb/beans.Counter");

      // Get a reference from this to the bean's Home interface
      CounterHome home = (CounterHome)
        PortableRemoteObject.narrow(ref, CounterHome.class);

      // Create a Counter object from the Home interface
      Counter counter = home.create();
      return counter.countLetters(word);
    }
    catch (Exception e) {
      throw new RuntimeException(e.getMessage());
    }
  }

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}