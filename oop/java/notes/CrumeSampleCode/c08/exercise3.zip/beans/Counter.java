package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface Counter extends EJBObject {
  // the public business method on the Counter bean
  public int countLetters(String word)
    throws RemoteException;
}