package client;

import beans.Builder;
import beans.BuilderHome;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class BuilderCounterClient { 
  public static void main(String[] args) {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the Builder JNDI entry
      Object ref  = jndiContext.lookup("ejb/beans.Builder");

      // Get a reference from this to the bean's Home interface
      BuilderHome home = (BuilderHome)
        PortableRemoteObject.narrow(ref, BuilderHome.class);

      // Create a Builder object from the Home interface
      Builder builder = home.create();
      
      // loop through the words
      for (int i = 0; i < args.length; i++) {
        String returnedString =
          builder.addWord(args[i]);
        System.out.println("sent string: " + args[i]
          + ", received string: " + returnedString);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}