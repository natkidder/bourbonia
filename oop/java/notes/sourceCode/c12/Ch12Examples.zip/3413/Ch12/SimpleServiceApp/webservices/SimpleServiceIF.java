package webservices;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SimpleServiceIF extends Remote {
  // the service methods
  public String getEchoString(String clientString)
    throws RemoteException;
}
