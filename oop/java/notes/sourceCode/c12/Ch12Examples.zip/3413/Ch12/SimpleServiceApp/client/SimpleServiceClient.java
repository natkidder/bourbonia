package client;

import webservices.SimpleServiceIF;
import webservices.SimpleService_Impl; 

import javax.xml.rpc.Stub;

public class SimpleServiceClient { 
  public static void main(String[] args) {
    try {
      Stub stub = (Stub)
          (new SimpleService_Impl().getSimpleServiceIFPort());
      SimpleServiceIF myProxy = (SimpleServiceIF)stub;
      System.out.println("got service!");
      
      // loop through the words
      for (int i = 0; i < args.length; i++) {
        String returnedString =
          myProxy.getEchoString(args[i]);
        System.out.println("sent string: " + args[i]
          + ", received string: " + returnedString);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}
