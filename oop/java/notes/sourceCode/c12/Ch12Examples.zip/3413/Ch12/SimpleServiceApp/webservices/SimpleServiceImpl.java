package webservices;

public class SimpleServiceImpl implements SimpleServiceIF  {

  // the service method implementations

  public String getEchoString(String clientString) {
    return clientString + " back at you!";
  }
}
