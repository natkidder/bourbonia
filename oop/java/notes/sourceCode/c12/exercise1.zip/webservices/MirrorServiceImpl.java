package webservices;

public class MirrorServiceImpl implements MirrorServiceIF  {
  
  // the service method implementations

  public String reverseIt(String clientString) {
    char[] oldOrder = clientString.toCharArray();
    char[] newOrder = new char[oldOrder.length];
    for (int i = 0; i < oldOrder.length; i++) {
      newOrder[oldOrder.length - 1 - i] = oldOrder[i];
    }
    return new String(newOrder);
  }
}
