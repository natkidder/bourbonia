package webservices;

public class CalculatorServiceImpl 
  implements CalculatorServiceIF  {
  
  // the service method implementations

  public int calculate(int op1, String oper, int op2) {
    if (oper.equals("+")) {
      // if "+", add it
      return op1 + op2;
    }    
    else {
      // if "-", subtract it
      return op1 - op2;
    }    
  }
}
