package webservices;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CalculatorServiceIF extends Remote {
  // the service methods
  public int calculate(int op1, String oper, int op2)
    throws RemoteException;
}