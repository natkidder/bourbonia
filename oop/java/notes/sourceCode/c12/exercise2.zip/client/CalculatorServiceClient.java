package client;

import webservices.CalculatorServiceIF;
import webservices.CalculatorService_Impl; 

import javax.xml.rpc.Stub;

public class CalculatorServiceClient {
  public static void main(String[] args) {
    try {
      Stub stub = (Stub)
        (new CalculatorService_Impl().getCalculatorServiceIFPort());
      CalculatorServiceIF myProxy = (CalculatorServiceIF) stub;
      System.out.println("got service!");
      
      // run a couple of operations
      System.out.println("1 + 5 = " + myProxy.calculate(1, "+", 5));
      System.out.println("8 - 4 = " + myProxy.calculate(8, "-", 4));
      System.out.println("4 + 3 = " + myProxy.calculate(4, "+", 3));
      System.out.println("2 - 7 = " + myProxy.calculate(2, "-", 7));
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}