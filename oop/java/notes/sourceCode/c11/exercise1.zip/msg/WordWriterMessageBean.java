package msg;

import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class WordWriterMessageBean
  implements MessageDrivenBean, MessageListener {

  // save the message driven context
  private MessageDrivenContext mdContext;

  // abstract method from message listener. here is where the 
  // work is done.
  public void onMessage(Message message) {
    TextMessage msg = null;

    try {
      if (message instanceof TextMessage) {
        msg = (TextMessage) message;
        System.out.println("Word received: " + msg.getText());
      }
      else {
        System.out.println("Got message of type: " 
          + message.getClass().getName() + " ==> ignored!");
      }
    }
    catch (JMSException e) {
      mdContext.setRollbackOnly();
    }
    catch (Throwable te) {
      te.printStackTrace();
    }
  }

  // set the context
  public void setMessageDrivenContext(MessageDrivenContext mdContext) {
    this.mdContext = mdContext;
  }

  // standard ejb methods
  
  public void ejbCreate() { }
  public void ejbRemove() { }
}
