package client;

import beans.MessageHandler;
import beans.MessageHandlerHome;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class WordWriterMessageClient {
  public static void main(String[] args) {
    try {
      InitialContext jndiContext = new InitialContext();

      Object ref  = jndiContext.lookup("ejb/beans.MessageHandler");

      MessageHandlerHome home = (MessageHandlerHome)
       PortableRemoteObject.narrow(ref, MessageHandlerHome.class);

      MessageHandler messageHandler = home.create();
      
      // loop through the words
      for (int i = 0; i < args.length; i++) {
        messageHandler.sendMessage(args[i]);
        System.out.println("sent string: " + args[i]);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}

