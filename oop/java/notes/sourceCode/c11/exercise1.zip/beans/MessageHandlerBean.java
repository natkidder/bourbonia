package beans;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

public class MessageHandlerBean implements SessionBean {  
  public void sendMessage(String clientString) {
    QueueConnection queueConnection = null;
    try {
      Context jndiContext = new InitialContext();
      QueueConnectionFactory queueConnectionFactory = 
        (QueueConnectionFactory)
        jndiContext.lookup("jms/QueueConnectionFactory");
      Queue queue = (Queue) jndiContext.lookup("jms/LogWriterQueue");
      
      queueConnection = 
        queueConnectionFactory.createQueueConnection();
      QueueSession queueSession = 
        queueConnection.createQueueSession(false, 
        Session.AUTO_ACKNOWLEDGE);
      QueueSender queueSender = queueSession.createSender(queue);
      TextMessage message = queueSession.createTextMessage();
      System.out.println("Sending word: " + clientString);
       message.setText(clientString);
      queueSender.send(message);
      if (queueConnection != null) {
        try {
          queueConnection.close();
        }
        catch (Exception e) {}
      }
    } catch (Exception e) {
        System.out.println("Exception occurred: " + e.toString());
    }
    finally {
      if (queueConnection != null) {
        try {
          queueConnection.close();
        }
        catch (Exception e) {}
      }
    }
  }

  // Standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}