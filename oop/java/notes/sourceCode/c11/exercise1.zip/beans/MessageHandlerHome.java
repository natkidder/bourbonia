package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.CreateException;

public interface MessageHandlerHome extends EJBHome {
  public MessageHandler create()
    throws CreateException, RemoteException;
}