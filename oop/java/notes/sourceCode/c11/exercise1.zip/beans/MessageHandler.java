package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface MessageHandler extends EJBObject {
  public void sendMessage(String clientString)
    throws RemoteException;
}