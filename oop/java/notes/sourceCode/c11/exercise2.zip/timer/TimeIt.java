package timer;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface TimeIt extends EJBObject {
  // the public business method on the timer bean
  public void startTimers() throws RemoteException;
}