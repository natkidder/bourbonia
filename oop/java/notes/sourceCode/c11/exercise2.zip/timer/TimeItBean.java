package timer;

import java.util.Date;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.TimedObject;
import javax.ejb.Timer;
import javax.ejb.TimerService;

public class TimeItBean
  implements SessionBean, TimedObject {
  // save a reference to the context
  private SessionContext ctx;
  
  // public business method to start the timer
  public void startTimers() {
    TimerService timerService = ctx.getTimerService();
    // after initial 10 seconds, then every ten seconds
    Timer timer1 =
      timerService.createTimer(10000, 10000, "10 second timer");
    // after 20 seconds one time
    Timer timer2 =
      timerService.createTimer(20000, "20 second single action");
    // by date, 30 seconds later, one time
    Date expTime = new Date((new Date()).getTime() + 30000);
    Timer timer3 =
      timerService.createTimer(expTime, "By date single action");
  }
  
  // timer ejb method - timer expires
  public void ejbTimeout(Timer timer) {
    System.err.println("timer expired: " + 
      ((String) timer.getInfo()));
  }
  
  // standard ejb methods
  
  public void setSessionContext(SessionContext context) {
    ctx = context;
  }

  public void ejbCreate() {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
}
