package client;

import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import timer.TimeIt;
import timer.TimeItHome;

public class TimeItClient { 
  public static void main(String[] args) {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the TimeIt JNDI entry
      Object ref  = jndiContext.lookup("ejb/timer.TimeIt");

      // Get a reference from this to the Bean's Home interface
      TimeItHome home = (TimeItHome)
       PortableRemoteObject.narrow(ref, TimeItHome.class);

      // Create a TimeIt object from the Home interface
      TimeIt timeIt = home.create();
      
      timeIt.startTimers ();
      
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}