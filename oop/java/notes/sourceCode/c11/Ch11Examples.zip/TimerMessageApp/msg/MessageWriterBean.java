package msg;

import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class MessageWriterBean
  implements MessageDrivenBean, MessageListener {

  // abstract method from message listener. here is where the
  // work is done.
  public void onMessage(Message message) {
    TextMessage msg = null;

    try {
      if (message instanceof TextMessage) {
        msg = (TextMessage) message;
        System.out.println("Got message: " + msg.getText());
      }
      else {
        System.out.println("Got message of type: "
          + message.getClass().getName() + " ==> ignored!");
      }
    }
    catch (Throwable te) {
      te.printStackTrace();
    }
  }

  // standard ejb methods
  public void ejbCreate() { }
  public void ejbRemove() { }
  public void setMessageDrivenContext(MessageDrivenContext mdContext) { }
}
