package timer;

import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class TimeItTester { 
  public static void main(String[] args) {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the SimpleSession JNDI entry
      Object ref  = jndiContext.lookup("ejb/timer.TimeIt");

      // Get a reference from this to the Bean's Home interface
      TimeItHome home = (TimeItHome)
       PortableRemoteObject.narrow(ref, TimeItHome.class);

      // Create a SimpleSession object from the Home interface
      TimeIt timeIt = home.create();
      
      timeIt.startTimer();
      
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}