package timer;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.TimedObject;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;

// general imports
import java.text.*;
import java.util.*;

public class TimeItBean
  implements SessionBean, TimedObject {
  // save a reference to the context
  private SessionContext ctx;

  // public business method to start the timer
  public void startTimer() {
    TimerService timerService = ctx.getTimerService();
    // after initial five seconds, then every ten seconds
    Timer timer = timerService.createTimer(5000, 10000, "timer");
  }

  // timer ejb method - timer expires - send message to queue
  public void ejbTimeout(Timer timer) {
    QueueConnection queueConnection = null;
    try {
      InitialContext jndiContext = new InitialContext();
      // lookup the connection factory
      QueueConnectionFactory queueConnectionFactory =
        (QueueConnectionFactory) jndiContext.lookup
        ("jms/QueueConnectionFactory");
      // lookup the queue (destination)
      Queue queue =
        (Queue) jndiContext.lookup("jms/LogWriterQueue");
      // get a connection from the factory
      queueConnection =
        queueConnectionFactory.createQueueConnection();
      // create a session
      QueueSession queueSession =
        queueConnection.createQueueSession(false,
        Session.AUTO_ACKNOWLEDGE);
      // create a sender for the session to the queue
      QueueSender queueSender = queueSession.createSender(queue);
      // create a text message
      TextMessage message = queueSession.createTextMessage();
      // create the message - a string to print on the other side
      SimpleDateFormat sdf =
        new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss.SSS");
      // set the text of the message
      message.setText
        ("log entry, the time is: " + sdf.format(new Date()));
      // send the message
      queueSender.send(message);

    }
    catch (Exception e) {
      System.out.println("Exception in message: " + e.toString());
      e.printStackTrace();
    }
    finally {
      if (queueConnection != null) {
        try {
          queueConnection.close();
        }
        catch (Exception e) {}
      }
    }
  }

  // standard ejb methods

  public void setSessionContext(SessionContext context) {
    ctx = context;
  }

  public void ejbCreate() {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
}
