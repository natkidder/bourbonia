package facade;

import beans.StockList;
import beans.StockListHome;
import vo.AnalystVo;
import vo.StockVo;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

// general imports
import java.util.*;

public class StockListFacade {
  // reference to singleton facade
  private static StockListFacade stockListFacade;

  // the reference to the stock list bean
  private StockList stockList;

  // private constructor - makes connection to session bean
  private StockListFacade() throws StockListException {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the StockList JNDI entry
      Object ref  = jndiContext.lookup("ejb/beans.StockList");

      // Get a reference from this to the Bean's Home interface
      StockListHome home = (StockListHome)
        PortableRemoteObject.narrow(ref, StockListHome.class);

      // Create a StockList object from the Home interface
      stockList = home.create();
    } catch(Exception e) {
      throw new StockListException(e.getMessage());
    }
  }

  // the business methods. no exposure to actual implementation
  // on the server or the communication method between client and
  // server is hidden to the client.

  public ArrayList getStockRatings() throws StockListException {
    try {
      ArrayList ratings = stockList.getStockRatings();
      return ratings;
    }
    catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public ArrayList getAllAnalysts() throws StockListException {
    try {
      ArrayList analysts = stockList.getAllAnalysts();
      return analysts;
    }
    catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public ArrayList getUnratedStocks() throws StockListException {
    try {
      ArrayList stocks = stockList.getUnratedStocks();
      return stocks;
    }
    catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public void addStockRating(StockVo stock)
    throws StockListException {
    try {
      stockList.addStockRating(stock);
    }
    catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public void addAnalyst(AnalystVo analyst)
    throws StockListException {
    try {
      stockList.addAnalyst(analyst);
    }
    catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public void addStock(StockVo stock) throws StockListException {
    try {
      stockList.addStock(stock);
    }
    catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public static StockListFacade getFacade()
    throws StockListException {
    if (stockListFacade == null) {
      stockListFacade = new StockListFacade();
    }

    return stockListFacade;
  }
}