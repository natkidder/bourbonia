package beans;

import vo.AnalystVo;
import vo.StockVo;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;

// general imports
import java.util.*;

public class StockListBean implements SessionBean {
  
  // the public business methods. these must be coded in the 
  // remote interface also. 
  
  public ArrayList getStockRatings() {
    try {
      // get the initial context
      InitialContext initial = new InitialContext();
      // get the object reference
      LocalStockHome home = (LocalStockHome)
        initial.lookup("java:comp/env/ejb/beans.Stock");
        
      // get the stocks
      ArrayList stkList = new ArrayList();
      Collection stocks = home.findRatedStocks();
      Iterator i = stocks.iterator();
      while (i.hasNext()) {
        LocalStock stock = (LocalStock) i.next();
        StockVo stockVo = new StockVo(stock.getTickerSymbol(),
          stock.getName(), stock.getRating());
        LocalAnalyst analyst = stock.getAnalyst();
        AnalystVo analystVo = new AnalystVo(analyst.getAnalystId(),
          analyst.getName());
        stockVo.setAnalyst(analystVo);
        stkList.add(stockVo);
      }
      
      return stkList;
    }
    catch (Exception e) {
      throw new EJBException(e.getMessage());
    }
  }
  
  public ArrayList getAllAnalysts() {
    try {
      // get the initial context
      InitialContext initial = new InitialContext();
      // get the object reference
      LocalAnalystHome home = (LocalAnalystHome)
        initial.lookup("java:comp/env/ejb/beans.Analyst");
        
      // get the analysts
      ArrayList analystList = new ArrayList();
      Collection analysts = home.findAllAnalysts();
      Iterator i = analysts.iterator();
      while (i.hasNext()) {
        LocalAnalyst analyst = (LocalAnalyst) i.next();
        AnalystVo analystVo = new AnalystVo(analyst.getAnalystId(),
          analyst.getName());
        analystList.add(analystVo);
      }
      
      return analystList;
    }
    catch (Exception e) {
      throw new EJBException(e.getMessage());
    }
  }
  
  public ArrayList getUnratedStocks() {
    try {
      // get the initial context
      InitialContext initial = new InitialContext();
      // get the object reference
      LocalStockHome home = (LocalStockHome)
        initial.lookup("java:comp/env/ejb/beans.Stock");
        
      // get the rated stocks
      Collection stocks = home.findRatedStocks();
      LocalStock[] ratedStocks = new LocalStock[stocks.size()];
      Iterator i = stocks.iterator();
      int ctr = 0;
      while (i.hasNext()) {
        LocalStock stock = (LocalStock) i.next();
        ratedStocks[ctr++] = stock;
      }
      
      // get all stocks
      Collection allStocks = home.findAllStocks();
      ArrayList stkList = new ArrayList();
      
      // eliminate the rated stocks
      Iterator j = allStocks.iterator();
      while (j.hasNext()) {
        LocalStock stock = (LocalStock) j.next();
        boolean rated = false;
        for (int k = 0; k < ratedStocks.length; k++) {
          String ratedTicker = ratedStocks[k].getTickerSymbol();
          if (stock.getTickerSymbol().equals(ratedTicker)) {
            rated = true;
            break;
          }
        }
        if (!rated) {
          StockVo stockVo = new StockVo(stock.getTickerSymbol(),
            stock.getName(), null);
          stkList.add(stockVo);
        }
      }
      
      return stkList;
    }
    catch (Exception e) {
      throw new EJBException(e.getMessage());
    }
  }
  
  public void addStockRating(StockVo stockVo) {
    try {
      // get the initial context
      InitialContext initial = new InitialContext();
      // get the home references
      LocalStockHome stockHome = (LocalStockHome)
        initial.lookup("java:comp/env/ejb/beans.Stock");
      LocalAnalystHome analystHome = (LocalAnalystHome)
        initial.lookup("java:comp/env/ejb/beans.Analyst");
      LocalStock stock = 
        stockHome.findByPrimaryKey(stockVo.getTickerSymbol());
      // get the local refs
      LocalAnalyst analyst = analystHome.findByPrimaryKey(
        stockVo.getAnalyst().getAnalystId());
      analyst.assignStock(stock);
      stock.setRating(stockVo.getRating());
    }
    catch (Exception e) {
      e.printStackTrace();
      throw new EJBException(e.getMessage());
    }
  }
  
  public void addAnalyst(AnalystVo analystVo) {
    try {
      InitialContext initial = new InitialContext();
      // get the object reference
      LocalAnalystHome analystHome = (LocalAnalystHome)
        initial.lookup("java:comp/env/ejb/beans.Analyst");
      analystHome.create(analystVo.getAnalystId(),
        analystVo.getName());
    }
    catch (Exception e) {
      e.printStackTrace();
      throw new EJBException(e.getMessage());
    }
  }
  
  public void addStock(StockVo stockVo) {
    try {
      InitialContext initial = new InitialContext();
      // get the object reference
      LocalStockHome stockHome = (LocalStockHome)
        initial.lookup("java:comp/env/ejb/beans.Stock");
      stockHome.create(stockVo.getTickerSymbol(),
        stockVo.getName());
    }
    catch (Exception e) {
      e.printStackTrace();
      throw new EJBException(e.getMessage());
    }
  }

  // standard ejb methods
  public void ejbActivate() { }
  public void ejbPassivate() { }
  public void ejbRemove() { }
  public void ejbCreate() { }
  public void setSessionContext(SessionContext context) { }
}