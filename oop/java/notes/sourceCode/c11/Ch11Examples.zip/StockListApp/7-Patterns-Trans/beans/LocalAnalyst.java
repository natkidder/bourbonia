package beans;

import javax.ejb.EJBLocalObject;

import java.util.*;

public interface LocalAnalyst extends EJBLocalObject  {
  // the public business methods on the Analyst bean
  // these include the accessor methods from the bean
  
  // add stock assignment
  public void assignStock(LocalStock stock);
  
  // get the id, no setter because primary key
  public Integer getAnalystId();
  
  // get and set the name
  public String getName();
  public void setName(String name);
  
  // the public cmr methods on the Analyst bean
  // these include the cmr methods from the bean
  // no setters exposed to the local interface
  public abstract Collection getStocks();
}