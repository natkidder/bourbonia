package vo;

import java.io.Serializable;
import java.util.*;

public class AnalystVo implements Serializable {

  // holds references to the attribute data
  private Integer analystId;
  private String name;

  // holds references to the relationships
  private ArrayList stocks;

  public AnalystVo(Integer analystId, String name) {
    this.analystId = analystId;
    this.name = name;
    stocks = new ArrayList();
  }

  // get analyst id. no setter because primary key
  public Integer getAnalystId() {
    return analystId;
  }

  // get, set name
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  // get stocks
  public ArrayList getStocks() {
    return stocks;
  }
}