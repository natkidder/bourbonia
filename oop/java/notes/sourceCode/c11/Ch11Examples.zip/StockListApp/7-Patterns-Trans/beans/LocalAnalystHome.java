package beans;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

// general imports
import java.util.*;

public interface LocalAnalystHome extends EJBLocalHome {
  // the create method for the Analyst bean
  public LocalAnalyst create(Integer id, String name)
    throws CreateException;
  
  // the find by primary key method for the Analyst bean
  public LocalAnalyst findByPrimaryKey(Integer id)
    throws FinderException;
  
  // the find all method for the Analyst bean
  public Collection findAllAnalysts()
    throws FinderException;
}