package facade;

public class StockListException extends Exception {
  
  public StockListException(String msg) {
    super(msg); 
  }
}