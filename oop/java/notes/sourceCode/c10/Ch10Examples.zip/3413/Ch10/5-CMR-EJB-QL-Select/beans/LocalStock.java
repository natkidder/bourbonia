package beans;

import javax.ejb.EJBLocalObject;
import javax.ejb.FinderException;

public interface LocalStock extends EJBLocalObject {
  // the public business methods on the Stock bean
  // these include the accessor methods from the bean
      
  // find rated stock analyst name
  public String getAnalystName() throws FinderException;
  
  // get the ticker, no setter because primary key
  public String getTickerSymbol();
  
  // get and set the name
  public String getName();
  public void setName(String name);
  
  // get and set the rating
  public String getRating();
  public void setRating(String rating);

  // the public cmr methods on the Stock bean
  // these include the cmr methods from the bean
  // no setters exposed to the local interface
  public LocalAnalyst getAnalyst();
}