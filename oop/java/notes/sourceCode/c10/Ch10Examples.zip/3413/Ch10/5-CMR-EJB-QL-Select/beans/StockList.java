package beans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

// general imports
import java.util.*;

public interface StockList extends EJBObject {
  // the public business methods on the Stock List bean
  public ArrayList getStockRatings() throws RemoteException;
  public ArrayList getAllAnalysts() throws RemoteException;
  public ArrayList getUnratedStocks() throws RemoteException;
  public void addStockRating(String ticker, Integer analystId,
    String rating) throws RemoteException;  
  public void addAnalyst(Integer id, String name)
    throws RemoteException;
  public void addStock(String ticker, String name) 
    throws RemoteException;
}