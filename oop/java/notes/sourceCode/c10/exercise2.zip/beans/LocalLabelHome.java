package beans;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

public interface LocalLabelHome extends EJBLocalHome {
  public LocalLabel create(String name, String city)
    throws CreateException;
  
  public LocalLabel findByPrimaryKey(String name) 
    throws FinderException;
}