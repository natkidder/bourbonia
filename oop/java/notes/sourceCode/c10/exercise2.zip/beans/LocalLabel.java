package beans;

import javax.ejb.EJBLocalObject;

import java.util.*;

public interface LocalLabel extends EJBLocalObject  {
  // get the name
  public String getName();
  
  // get and set the city
  public String getMainCity();
  public void setMainCity(String city);
  
  public Collection getCompactDiscTitles();
}