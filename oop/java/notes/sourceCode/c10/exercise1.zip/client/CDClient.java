package client;

import beans.CDList;
import beans.CDListHome;

import java.text.NumberFormat;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class CDClient { 
  
  public static void main(String[] args) {
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the CDList JNDI entry
      Object ref = jndiContext.lookup("ejb/beans.CDList");

      // Get a reference from this to the Bean's Home interface
      CDListHome home = (CDListHome)
        PortableRemoteObject.narrow(ref, CDListHome.class);

      // Create a CDList object from the Home interface
      CDList cdList = home.create();
      
      // Add labels
      System.out.println("Adding labels");
      cdList.addLabel("Jim and Jim Recording", "Marion");
      cdList.addLabel("Squirrel and Acorn", "Oakland");
      cdList.addLabel("The label", "London");
      System.out.println("Labels added");
      
      System.out.println("Label: Jim and Jim Recording" + 
        "  City: " + cdList.getLabel("Jim and Jim Recording"));
        
      // Add cds
      System.out.println("Adding CDs");
      cdList.addCD("Hey! Ho! Hey!", 13.95, "Squirrel and Acorn");
      cdList.addCD("Java Is Cool!", 19.95, "Jim and Jim Recording");
      cdList.addCD("No More Cats", 11.95, "Squirrel and Acorn");
      System.out.println("CDs added");
      
      NumberFormat nf = NumberFormat.getCurrencyInstance();
      
      Object[] vals1 = cdList.getCD("Hey! Ho! Hey!");   
      System.out.println("Title: Hey! Ho! Hey!   Price: " +
        nf.format(((Double) vals1[0]).doubleValue()) +
        "   Label: " + ((String) vals1[1]));
      
      Object[] vals2 = cdList.getCD("Java Is Cool!");   
      System.out.println("Title: Java Is Cool!   Price: " +
        nf.format(((Double) vals2[0]).doubleValue()) +
        "   Label: " + ((String) vals2[1]));
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}