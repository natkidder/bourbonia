package beans;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

public interface CDList extends EJBObject {
  public Object[] getCD(String name)
    throws FinderException, RemoteException;
  public void addCD(String name, double price, String label)
    throws CreateException, RemoteException;
  public String getLabel(String name)
    throws FinderException, RemoteException;
  public void addLabel(String name, String city)
    throws CreateException, RemoteException;
}