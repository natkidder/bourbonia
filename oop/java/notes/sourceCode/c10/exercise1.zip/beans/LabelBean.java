package beans;

import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;

import java.util.*;

public abstract class LabelBean implements EntityBean {

  // keeps the reference to the context
  private EntityContext _context;

  // the abstract access methods for persistent fields
  public abstract String getName();
  public abstract void setName(String name);
  
  public abstract String getMainCity();
  public abstract void setMainCity(String city);
  
  public abstract Collection getCompactDiscTitles();
  public abstract void setCompactDiscTitles(Collection titles);
  

  // standard entity bean methods

  public String ejbCreate(String name, String city)
    throws CreateException {

    setName(name);
    setMainCity(city);
    return null;
  }
         
  public void ejbPostCreate(String name, String city)
    throws CreateException { }

  public void setEntityContext(EntityContext ctx) {
      _context = ctx;
  }
    
  public void unsetEntityContext() {
      _context = null;
  }
    
  public void ejbRemove() { }
  public void ejbLoad() { }
  public void ejbStore() { }
  public void ejbPassivate() { }
  public void ejbActivate() { }
}