package beans;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class CDListBean implements SessionBean {
  
  // the public business methods. these must be coded in the 
  // remote interface also. 
  
  public Object[] getCD(String name) throws FinderException {
    try {
      Object[] vals = new Object[2];
      LocalCDHome cdHome = getCDHome();
      LocalCD cd = cdHome.findByPrimaryKey(name);
      vals[0] = new Double(cd.getPrice());
      vals[1] = cd.getRecordLabel().getName();
      return vals;
    }
    catch (FinderException fe) {
      throw fe;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  public void addCD(String name, double price, String label)
    throws CreateException {
    try {
      LocalCDHome cdHome = getCDHome();
      cdHome.create(name, price, label);
    }
    catch (CreateException ce) {
      throw ce;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  public String getLabel(String name) throws FinderException {
    try {
      LocalLabelHome labelHome = getLabelHome();
      LocalLabel label = labelHome.findByPrimaryKey(name);
      return label.getMainCity();
    }
    catch (FinderException fe) {
      throw fe;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  public void addLabel(String name, String city)
    throws CreateException {
    try {
      LocalLabelHome labelHome = getLabelHome();
      labelHome.create(name, city);
    }
    catch (CreateException ce) {
      throw ce;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  private LocalCDHome getCDHome() throws NamingException {
    // get the initial context
    InitialContext initial = new InitialContext();
    
    // get the object reference
    Object objref = initial.lookup("java:comp/env/ejb/beans.CD");
    LocalCDHome home = (LocalCDHome) objref;
    return home;
  }
  
  private LocalLabelHome getLabelHome() throws NamingException {
    // get the initial context
    InitialContext initial = new InitialContext();
    
    // get the object reference
    Object objref = initial.lookup("java:comp/env/ejb/beans.Label");
    LocalLabelHome home = (LocalLabelHome) objref;
    return home;
  }
  

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}