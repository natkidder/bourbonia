package beans;

import javax.ejb.EJBLocalObject;

public interface LocalCD extends EJBLocalObject  {
  // get the name
  public String getName();
  
  // get and set the price
  public double getPrice();
  public void setPrice(double price);
  
  // get the record label
  public LocalLabel getRecordLabel();
}