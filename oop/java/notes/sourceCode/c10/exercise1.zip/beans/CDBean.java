package beans;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.naming.InitialContext;

public abstract class CDBean implements EntityBean {

  // keeps the reference to the context
  private EntityContext _context;

  // the abstract access methods for persistent fields
  public abstract String getName();
  public abstract void setName(String name);
  
  public abstract double getPrice();
  public abstract void setPrice(double price);
  
  public abstract LocalLabel getRecordLabel();
  public abstract void setRecordLabel(LocalLabel label);
  

  // standard entity bean methods

  public String ejbCreate(String name, double price,
    String label) throws CreateException {

    setName(name);
    setPrice(price);
    
    return null;
  }
         
  public void ejbPostCreate(String name, double price,
    String label) throws CreateException {
    
    // set the cmr
    try {
      InitialContext initial = new InitialContext();
      LocalLabelHome labelHome = (LocalLabelHome)
        initial.lookup("java:comp/env/ejb/beans.Label");
      // get the local refs
      LocalLabel labelRef = 
        labelHome.findByPrimaryKey(label);
      setRecordLabel(labelRef);
    }
    catch (Exception e) {
      e.printStackTrace();
      throw new EJBException(e.getMessage());
    }
  }

  public void setEntityContext(EntityContext ctx) {
      _context = ctx;
  }
    
  public void unsetEntityContext() {
      _context = null;
  }
    
  public void ejbRemove() { }
  public void ejbLoad() { }
  public void ejbStore() { }
  public void ejbPassivate() { }
  public void ejbActivate() { }
}