package beans;

import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;

public abstract class CDBean implements EntityBean {

  // keeps the reference to the context
  private EntityContext _context;

  // the abstract access methods for persistent fields
  public abstract String getName();
  public abstract void setName(String name);
  
  public abstract double getPrice();
  public abstract void setPrice(double price);
  

  // standard entity bean methods

  public String ejbCreate(String name, double price)
    throws CreateException {

    setName(name);
    setPrice(price);
    return null;
  }
         
  public void ejbPostCreate(String name, double price)
    throws CreateException { }

  public void setEntityContext(EntityContext ctx) {
      _context = ctx;
  }
    
  public void unsetEntityContext() {
      _context = null;
  }
    
  public void ejbRemove() { }
  public void ejbLoad() { }
  public void ejbStore() { }
  public void ejbPassivate() { }
  public void ejbActivate() { }
}