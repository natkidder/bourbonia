package beans;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class CDListBean implements SessionBean {
  
  // the public business methods. these must be coded in the 
  // remote interface also. 
  
  public double getCD(String name) throws FinderException {
    try {
      LocalCDHome cdHome = getCDHome();
      LocalCD cd = cdHome.findByPrimaryKey(name);
      return cd.getPrice();
    }
    catch (FinderException fe) {
      throw fe;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  public void addCD(String name, double price)
    throws CreateException {
    try {
      LocalCDHome cdHome = getCDHome();
      cdHome.create(name, price);
    }
    catch (CreateException ce) {
      throw ce;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
    
  public void updateCD(String name, double price)
   throws FinderException {
    try {
      LocalCDHome cdHome = getCDHome();
      LocalCD cd = cdHome.findByPrimaryKey(name);
      cd.setPrice(price);
    }
    catch (FinderException fe) {
      throw fe;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
   }
   
  public void deleteCD(String name)
    throws FinderException {
    try {
      LocalCDHome cdHome = getCDHome();
      LocalCD cd = cdHome.findByPrimaryKey(name);
      cd.remove();
    }
    catch (FinderException fe) {
      throw fe;
    }
    catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }
  
  private LocalCDHome getCDHome() throws NamingException {
    // get the initial context
    InitialContext initial = new InitialContext();
    
    // get the object reference
    Object objref = initial.lookup("java:comp/env/ejb/beans.CD");
    LocalCDHome home = (LocalCDHome) objref;
    return home;
  }
  

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}