package beans;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

public interface LocalCDHome extends EJBLocalHome {
  public LocalCD create(String name, double price)
    throws CreateException;
  
  public LocalCD findByPrimaryKey(String name) 
    throws FinderException;
}