package beans;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBObject;
import javax.ejb.FinderException;

public interface CDList extends EJBObject {
  public double getCD(String name)
    throws FinderException, RemoteException;
  public void addCD(String name, double price)
    throws CreateException, RemoteException;
  public void updateCD(String name, double price)
    throws FinderException, RemoteException;
  public void deleteCD(String name)
    throws FinderException, RemoteException;
}