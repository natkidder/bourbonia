package client;

import beans.CDList;
import beans.CDListHome;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

// general imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CDClient extends JFrame 
  implements ActionListener { 
  private CDList _cdList;
  private JTextField _name = new JTextField();
  private JTextField _price = new JTextField();
  private JButton _get = new JButton("Get");
  private JButton _add = new JButton("Add");
  private JButton _update = new JButton("Update");
  private JButton _delete = new JButton("Delete");
      
  public CDClient() {
    // get the cd lister
    _cdList = getCDList();
    
    // add the title
    JLabel title = new JLabel("CD List");
    title.setHorizontalAlignment(JLabel.CENTER);
    getContentPane().add(title, BorderLayout.NORTH);
    
    // add the cd label panel
    JPanel cdLabelPanel = new JPanel(new GridLayout(2, 1));
    cdLabelPanel.add(new JLabel("Name"));
    cdLabelPanel.add(new JLabel("Price"));
    getContentPane().add(cdLabelPanel, BorderLayout.WEST);
    
    // add the cd field panel
    JPanel cdFieldPanel = new JPanel(new GridLayout(2, 1));
    cdFieldPanel.add(_name);
    cdFieldPanel.add(_price);
    getContentPane().add(cdFieldPanel, BorderLayout.CENTER);
    
    // add the buttons
    JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
    _get.addActionListener(this);
    buttonPanel.add(_get);
    _add.addActionListener(this);
    buttonPanel.add(_add);
    _update.addActionListener(this);
    buttonPanel.add(_update);
    _delete.addActionListener(this);
    buttonPanel.add(_delete);
    getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });

    setSize(330, 130);
    setVisible(true);
  }
  
  private CDList getCDList() {
    CDList cdList = null;
    try {
      // Get a naming context
      InitialContext jndiContext = new InitialContext();

      // Get a reference to the CDList JNDI entry
      Object ref  = jndiContext.lookup("ejb/beans.CDList");

      // Get a reference from this to the Bean's Home interface
      CDListHome home = (CDListHome)
        PortableRemoteObject.narrow(ref, CDListHome.class);

      // Create a cd list object from the Home interface
      cdList = home.create();
    } catch(Exception e) {
      e.printStackTrace();
    }
    
    return cdList;
  }
  
  public void actionPerformed(ActionEvent ae) {
    // if get was clicked, get the cd
    if (ae.getSource() == _get) {
      getCD();
    }
    
    // if add was clicked, add the cd
    if (ae.getSource() == _add) {
      addCD();
    }
    
    // if update was clicked, update the cd
    if (ae.getSource() == _update) {
      updateCD();
    }
    
    // if delete was clicked, delete the cd
    if (ae.getSource() == _delete) {
      deleteCD();
    }
  }
  
  private void getCD() {
    // get the name
    String name = _name.getText();
    if (name == null || name.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Name is required");
      return;
    }
    
    // get the cd
    try {
      double price = _cdList.getCD(name.trim());
      _price.setText(Double.toString(price));
    }
    catch (FinderException fe) {
      JOptionPane.showMessageDialog(this, "Not found!");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  private void addCD() {
    // get the name
    String name = _name.getText();
    if (name == null || name.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Name is required");
      return;
    }
    
    // get the price
    String priceStr = _price.getText();
    if (priceStr == null || priceStr.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Price is required");
      return;
    }
    
    // validate the price
    double price = 0.0;
    try {
      price = Double.parseDouble(priceStr.trim());
    }
    catch (NumberFormatException nfe) {
      JOptionPane.showMessageDialog(this, "Price is invalid");
      return;
    }
    
    // add the cd
    try {
      _cdList.addCD(name.trim(), price);
      JOptionPane.showMessageDialog(this, "CD added!");
    }
    catch (CreateException fe) {
      JOptionPane.showMessageDialog(this, "Already found!");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  private void updateCD() {
    // get the name
    String name = _name.getText();
    if (name == null || name.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Name is required");
      return;
    }
    
    // get the price
    String priceStr = _price.getText();
    if (priceStr == null || priceStr.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Price is required");
      return;
    }
    
    // validate the price
    double price = 0.0;
    try {
      price = Double.parseDouble(priceStr.trim());
    }
    catch (NumberFormatException nfe) {
      JOptionPane.showMessageDialog(this, "Price is invalid");
      return;
    }
    
    //update the cd
    try {
      _cdList.updateCD(name.trim(), price);
      JOptionPane.showMessageDialog(this, "CD updated!");
    }
    catch (FinderException fe) {
      JOptionPane.showMessageDialog(this, "Not found!");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  private void deleteCD() {
    // get the name
    String name = _name.getText();
    if (name == null || name.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Name is required");
      return;
    }
    
    // delete the cd
    try {
      _cdList.deleteCD(name.trim());
      JOptionPane.showMessageDialog(this, "CD deleted!");
    }
    catch (FinderException fe) {
      JOptionPane.showMessageDialog(this, "Not found!");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  public static void main(String[] args) {
    CDClient stockClient = new CDClient();
  }
}