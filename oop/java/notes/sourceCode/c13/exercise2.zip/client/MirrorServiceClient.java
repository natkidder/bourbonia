package client;

import webservices.MirrorServiceIF;

import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceFactory;

import javax.xml.rpc.Stub;

public class MirrorServiceClient {
  public static void main(String[] args) {
    try {
      String serviceName = "MirrorService";
      String urlString = "http://localhost:1024/mirrorbean?WSDL";
      String nameSpaceUri = "urn:mirrorService";
      String portName = "MirrorServiceIFPort";

      URL wsdlUrl = new URL(urlString);
      ServiceFactory serviceFactory = ServiceFactory.newInstance();
      Service jaxService =
        serviceFactory.createService(wsdlUrl, 
        new QName(nameSpaceUri, serviceName));
            
      MirrorServiceIF myProxy = 
        (MirrorServiceIF) jaxService.getPort(
        new QName(nameSpaceUri, portName), MirrorServiceIF.class); 

      System.out.println("got service!");
      
      // loop through the words
      for (int i = 0; i < args.length; i++) {
        String returnedString =
          myProxy.reverseIt(args[i]);
        System.out.println("sent string: " + args[i]
          + ", received string: " + returnedString);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}
