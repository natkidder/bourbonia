package webservices;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MirrorServiceIF extends Remote {
  // the service methods
  public String reverseIt(String clientString)
    throws RemoteException;
}