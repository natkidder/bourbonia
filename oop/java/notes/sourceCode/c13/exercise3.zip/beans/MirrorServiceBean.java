package beans;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class MirrorServiceBean implements SessionBean {  
  // the public business method.
  public String reverseIt(String clientString) {
    char[] oldOrder = clientString.toCharArray();
    char[] newOrder = new char[oldOrder.length];
    for (int i = 0; i < oldOrder.length; i++) {
      newOrder[oldOrder.length - 1 - i] = oldOrder[i];
    }
    return new String(newOrder);
  }

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}