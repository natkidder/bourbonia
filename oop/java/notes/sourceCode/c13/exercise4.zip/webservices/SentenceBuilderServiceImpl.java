package webservices;

import javax.servlet.http.HttpSession;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.server.ServiceLifecycle;
import javax.xml.rpc.server.ServletEndpointContext;

public class SentenceBuilderServiceImpl
  implements SentenceBuilderServiceIF, ServiceLifecycle {
      
  private ServletEndpointContext _endpointContext = null;
  
  // service lifecycle methods
  public void init(Object context) throws ServiceException {
    _endpointContext = (ServletEndpointContext) context;
  }

  public void destroy() { }
  
  // the service business method implementations
  public String append(String word) {
    HttpSession session = _endpointContext.getHttpSession();
    StringBuffer sentence =
      (StringBuffer) session.getAttribute("sentence");
    if (sentence == null) {
      sentence = new StringBuffer();
    }
    
    sentence.append(sentence.length() == 0 ? "" : " ");
    sentence.append(word.trim());
    session.setAttribute("sentence", sentence);
    return sentence.toString();
  }
}
