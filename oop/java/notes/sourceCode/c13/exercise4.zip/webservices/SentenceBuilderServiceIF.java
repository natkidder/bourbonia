package webservices;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SentenceBuilderServiceIF extends Remote {
  // the service methods
  public String append(String word) throws RemoteException;
}
