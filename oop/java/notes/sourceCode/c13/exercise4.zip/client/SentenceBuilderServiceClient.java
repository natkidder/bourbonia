package client;

import webservices.SentenceBuilderServiceIF;

import java.rmi.ServerException;
import javax.xml.namespace.QName;
import javax.xml.rpc.Call;  
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceFactory;

import javax.xml.rpc.Stub;

public class SentenceBuilderServiceClient {
  public static void main(String[] args) {
    try {
      ServiceFactory factory = ServiceFactory.newInstance(); 
      Service service =
        factory.createService(new QName("SentenceBuilderService"));
      Call call = (Call) service.createCall();
      call.setPortTypeName(new QName("SentenceBuilderServiceIF")); 
      call.setTargetEndpointAddress(
        "http://localhost:1024/sentence-jaxrpc/sentence");
      call.setProperty(Call.SOAPACTION_USE_PROPERTY,
         new Boolean(true)); 
      call.setProperty(Call.SOAPACTION_URI_PROPERTY, "");  
      call.setProperty("javax.xml.rpc.encodingstyle.namespace.uri", 
          "http://schemas.xmlsoap.org/soap/encoding/");  
      call.setProperty(Call.SESSION_MAINTAIN_PROPERTY,
         new Boolean(true));
      System.out.println("got call!");
      
      // loop through the words
      for (int i = 0; i < args.length; i++) {
        Object[] parms =
          new Object[] { args[i] };
        call.removeAllParameters();
        call.setReturnType(
          new QName("http://www.w3.org/2001/XMLSchema", "string"));  
        call.setOperationName(new QName("urn:sentenceBuilderService",
                                         "append"));
        call.addParameter("String_1",
          new QName("http://www.w3.org/2001/XMLSchema", "string"),
          ParameterMode.IN);
        // invoke the service to display the new value
        String returnedString = (String) call.invoke(parms);
      
        System.out.println("sent string: " + args[i]
          + ", received string: " + returnedString);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}
