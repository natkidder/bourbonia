package client;

import webservices.MirrorServiceIF;
import webservices.MirrorService_Impl; 

import javax.xml.rpc.Stub;

public class MirrorServiceClient {
  public static void main(String[] args) {
    try {
      Stub stub = 
        (Stub)(new MirrorService_Impl().getMirrorServiceIFPort());
      MirrorServiceIF myProxy = (MirrorServiceIF)stub;
      System.out.println("got service!");
      
      // loop through the words
      for (int i = 0; i < args.length; i++) {
        String returnedString =
          myProxy.reverseIt(args[i]);
        System.out.println("sent string: " + args[i]
          + ", received string: " + returnedString);
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}