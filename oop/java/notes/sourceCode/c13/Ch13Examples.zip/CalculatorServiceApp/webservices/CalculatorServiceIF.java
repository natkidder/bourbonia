package webservices;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CalculatorServiceIF extends Remote {
  // the service methods
  public void clearIt() throws RemoteException;
  public void calculate(String operation, int value)
    throws Exception, RemoteException;
  public int getValue() throws RemoteException;
}
