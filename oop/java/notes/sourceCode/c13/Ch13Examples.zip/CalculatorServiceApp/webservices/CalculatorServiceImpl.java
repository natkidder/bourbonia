package webservices;

import javax.servlet.http.HttpSession;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.server.ServiceLifecycle;
import javax.xml.rpc.server.ServletEndpointContext;

public class CalculatorServiceImpl
  implements CalculatorServiceIF, ServiceLifecycle {

  private ServletEndpointContext _endpointContext = null;

  // service lifecycle methods
  public void init(Object context) throws ServiceException {
    _endpointContext = (ServletEndpointContext) context;
  }

  public void destroy() { System.out.println("destroying"); }

  // the service business method implementations
  public void clearIt() {
    HttpSession session = _endpointContext.getHttpSession();
    session.setAttribute("balance", new Integer(0));
  }

  public void calculate(String operation, int value)
    throws Exception {
    // get the balance
    HttpSession session = _endpointContext.getHttpSession();
    Integer val = pluckValue();
    int bal = val.intValue();

    // if "+", add it
    if (operation.equals("+")) {
      bal = bal + value;
      session.setAttribute("balance", new Integer(bal));
      return;
    }

    // if "-", subtract it
    if (operation.equals("-")) {
      bal = bal - value;
      if (bal < 0) {
        throw new Exception("Balance less than 0");
      }
      session.setAttribute("balance", new Integer(bal));
      return;
    }

    // if not "+" or "-", it is not a valid operation
    throw new Exception("Invalid Operation");
  }

  public int getValue() {
    return pluckValue().intValue();
  }

  private Integer pluckValue() {
    HttpSession session = _endpointContext.getHttpSession();
    Integer val = (Integer) session.getAttribute("balance");
    if (val == null) {
      val = new Integer(0);
    }
    return val;
  }
}
