package beans;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class SimpleSessionBean implements SessionBean {
  // the public business method. this must be coded in the
  // remote interface also.
  public String getEchoString(String clientString) {
    return clientString + " back at you!";
  }

  // standard ejb methods
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbRemove() {}
  public void ejbCreate() {}
  public void setSessionContext(SessionContext context) { }
}